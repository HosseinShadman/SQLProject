SELECT COUNT(DISTINCT Customer) as number_of_diffrent_customers
FROM saletable;