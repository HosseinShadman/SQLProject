SELECT Product, SUM(UnitPrice) as sum_UnitPrice INTO X
FROM saletable
GROUP BY Product;

select * from X
INNER JOIN saleprofit
ON X.Product = saleprofit.Product;

ALTER TABLE X
ADD answer float;

ALTER TABLE X
ADD Profit float; 

UPDATE X
SET Profit = saleprofit.ProfitRatio
FROM saleprofit
WHERE X.Product = saleprofit.Product

UPDATE X
SET answer = Profit * sum_UnitPrice

SELECT SUM(answer) as answer
FROM X;
