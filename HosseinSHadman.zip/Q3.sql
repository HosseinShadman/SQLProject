SELECT Product, SUM(Quantity) as sum_Quantity
FROM saletable
GROUP BY Product;