CREATE TABLE saleprofit (
	Product VARCHAR(255),
    ProfitRatio float
);

insert into saleprofit values ('P1',0.05);
insert into saleprofit values ('P2',0.25);
insert into saleprofit values ('P3',0.1);
insert into saleprofit values ('P4',0.2);
insert into saleprofit values ('P5',0.1);
insert into saleprofit values ('P6',0.1);

select * from saleprofit