SELECT SUM(UnitPrice) as sum_UnitPrice
FROM saletable;