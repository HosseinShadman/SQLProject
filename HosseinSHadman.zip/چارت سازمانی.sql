CREATE TABLE organizationalchart (
	Id INT,
	name VARCHAR(255),
	manager VARCHAR(255),
	ManagerId INT,
);			

insert into organizationalchart values (1,'Ken',NULL,NULL);
insert into organizationalchart values (2,'Hugo',NULL,NULL);
insert into organizationalchart values (3,'James','Carol',5);
insert into organizationalchart values (4,'Mark','Morgan',13);
insert into organizationalchart values (5,'Carol','Alex',12);
insert into organizationalchart values (6,'David','Rose',21);
insert into organizationalchart values (7,'Michael','Markos',11);
insert into organizationalchart values (8,'Brad','Alex',12);
insert into organizationalchart values (9,'Rob','Matt',15);
insert into organizationalchart values (10,'Dylan','Alex',12);
insert into organizationalchart values (11,'Markos','Carol',5);
insert into organizationalchart values (12,'Alex','Ken',1);
insert into organizationalchart values (13,'Morgan','Matt',15);
insert into organizationalchart values (14,'Jennifer','Morgan',13);
insert into organizationalchart values (15,'Matt','Hugo',2);
insert into organizationalchart values (16,'Tom','Brad',8);
insert into organizationalchart values (17,'Oliver','Dylan',10);
insert into organizationalchart values (18,'Daniel','Rob',9);
insert into organizationalchart values (19,'Amanda','Markos',11);
insert into organizationalchart values (20,'Ana','Dylan',10);
insert into organizationalchart values (21,'Rose','Rob',9);
insert into organizationalchart values (22,'Robert','Rob',9);
insert into organizationalchart values (23,'Fill','Morgan',13);
insert into organizationalchart values (24,'Antoan','David',6);
insert into organizationalchart values (25,'Eddie','Mark',4);

select * from organizationalchart
