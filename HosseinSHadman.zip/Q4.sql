SELECT * INTO Q4TABLE
FROM saletable
WHERE UnitPrice * Quantity > 1500;


SELECT Customer, SUM(UnitPrice) as sum_UnitPrice, COUNT(Customer) as number_of_orders, SUM(Quantity) as sum_Quantity
From Q4TABLE
GROUP BY Customer;